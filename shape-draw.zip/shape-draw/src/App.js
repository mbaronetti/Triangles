import React, { Component } from 'react';
import {Button} from 'antd';
import logo from './logo.svg';
import UI from './components/UI';

class App extends Component {
  render() {
    return (
      <div className="App">
        <UI />
      </div>
    );
  }
}

export default App;
